
#ifdef __cplusplus
extern "C" {
#endif
void VCAST_TI_8_1 ( char *vcast_param ) ;

void VCAST_TI_8_3 ( float *vcast_param ) ;

void VCAST_TI_9_1 ( struct table_data_type vcast_param[6] ) ;

void VCAST_TI_9_10 ( enum desserts *vcast_param ) ;

void VCAST_TI_9_11 ( enum beverages *vcast_param ) ;

void VCAST_TI_9_12 ( struct order_type *vcast_param ) ;

void VCAST_TI_9_13 ( char vcast_param[10] ) ;

void VCAST_TI_9_14 ( struct order_type vcast_param[4] ) ;

void VCAST_TI_9_2 ( struct table_data_type *vcast_param ) ;

void VCAST_TI_9_5 ( unsigned short *vcast_param ) ;

void VCAST_TI_9_6 ( enum boolean *vcast_param ) ;

void VCAST_TI_9_7 ( enum soups *vcast_param ) ;

void VCAST_TI_9_8 ( enum salads *vcast_param ) ;

void VCAST_TI_9_9 ( enum entrees *vcast_param ) ;


#ifdef __cplusplus
}
#endif
