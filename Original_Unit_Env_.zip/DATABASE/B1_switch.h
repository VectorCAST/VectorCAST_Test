/***********************************************
 *      VectorCAST Test Harness Component      *
 *     Copyright 2018 Vector Informatik, GmbH.    *
 *              18.sp2 (07/02/18)              *
 ***********************************************/
#ifndef B1_SWITCH_H
#define B1_SWITCH_H   

void vcast_B1_switch( int, int, int, char * );

#endif /* B1_SWITCH_H */
