
typedef int VECTORCAST_MARKER__UNIT_PREFIX_START;

#include "ctypes.h"
#undef SCU_CCUCON5
#define SCU_CCUCON5 vcast_SCU_CCUCON5
Ifx_SCU_CCUCON5 *vcast_SCU_CCUCON5;

typedef int VECTORCAST_MARKER__UNIT_PREFIX_END;
#include "C:/VCAST/Tutorial/c/manager.c"

typedef int VECTORCAST_MARKER__UNIT_APPENDIX_START;

typedef int VECTORCAST_MARKER__UNIT_APPENDIX_END;
