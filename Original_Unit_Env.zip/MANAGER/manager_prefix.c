
#include "ctypes.h"
#undef SCU_CCUCON5
#define SCU_CCUCON5 vcast_SCU_CCUCON5
Ifx_SCU_CCUCON5 *vcast_SCU_CCUCON5;

