
#ifdef __cplusplus
extern "C" {
#endif
void VCAST_TI_8_1 ( char *vcast_param ) ;

void VCAST_TI_8_2 ( int *vcast_param ) ;

void VCAST_TI_8_3 ( float *vcast_param ) ;

void VCAST_TI_9_10 ( enum boolean *vcast_param ) ;

void VCAST_TI_9_11 ( struct order_type vcast_param[4] ) ;

void VCAST_TI_9_12 ( enum soups *vcast_param ) ;

void VCAST_TI_9_13 ( char **vcast_param ) ;

void VCAST_TI_9_15 ( char vcast_param[10][32] ) ;

void VCAST_TI_9_16 ( struct _Ifx_SCU_CCUCON5_Bits *vcast_param ) ;

void VCAST_TI_9_17 ( signed int *vcast_param ) ;

void VCAST_TI_9_19 ( Ifx_SCU_CCUCON5 *vcast_param ) ;

void VCAST_TI_9_2 ( struct order_type **vcast_param ) ;

void VCAST_TI_9_20 ( Ifx_SCU_CCUCON5 **vcast_param ) ;

void VCAST_TI_9_22 ( unsigned short *vcast_param ) ;

void VCAST_TI_9_23 ( char vcast_param[10] ) ;

void VCAST_TI_9_24 ( char vcast_param[32] ) ;

void VCAST_TI_9_3 ( enum entrees *vcast_param ) ;

void VCAST_TI_9_4 ( unsigned *vcast_param ) ;

void VCAST_TI_9_5 ( enum salads *vcast_param ) ;

void VCAST_TI_9_6 ( enum beverages *vcast_param ) ;

void VCAST_TI_9_7 ( enum desserts *vcast_param ) ;

void VCAST_TI_9_8 ( struct order_type *vcast_param ) ;

void VCAST_TI_9_9 ( struct table_data_type *vcast_param ) ;


#ifdef __cplusplus
}
#endif
