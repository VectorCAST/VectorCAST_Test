/* Undefine all field names (disable by setting VCAST_DO_NOT_UNDEF_FIELDS) */
