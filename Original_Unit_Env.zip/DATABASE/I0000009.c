#define VCAST_COVERAGE
#include "S0000009.c"
